#!/bin/bash

tar cvxf v9.tar.xz v9.patch README.txt dockerimage
