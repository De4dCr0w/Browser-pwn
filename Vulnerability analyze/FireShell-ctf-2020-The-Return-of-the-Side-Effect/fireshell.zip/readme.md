Description: I always loved side-effects on JavaScript engines. I decided to add back a nice side-effect on JavaScriptCore, can you use such feature to read the flag?
Commit: 830f2e892431f6fea022f09f70f2f187950267b7
JSC will be running release with --useConcurrentJIT=false on the server
Note: You script must run within 10 seconds.
Machine: Ubuntu 18.04 LTS
Flag: /flag
Server: http://142.93.113.55:31089/
Files: jsc, libJavaScriptCode.so, patch.diff
